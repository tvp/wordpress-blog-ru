You have successfully created an account at <?php bloginfo(); ?>.

You can log into our site <?php echo get_bloginfo('wpurl').'/wp-login.php'; ?>.

Username : %username%
Password : %password%

To view your bookings, please visit <?php echo em_get_my_bookings_url(); ?> after logging in.